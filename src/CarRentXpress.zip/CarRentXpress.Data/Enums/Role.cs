namespace CarRentXpress.Data.Enums;

public enum Role
{
    User,
    Admin
}